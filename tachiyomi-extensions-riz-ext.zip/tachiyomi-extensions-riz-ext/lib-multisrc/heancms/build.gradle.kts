plugins {
    id("lib-multisrc")
}

baseVersionCode = 27

dependencies {
    api(project(":lib:i18n"))
}
